<?php
/**
 * Created by PhpStorm.
 * User: yidashi
 * Date: 2016/12/15
 * Time: 下午4:26
 */

namespace yii\helpers;


class Markdown extends BaseMarkdown
{
    public static $defaultFlavor = 'gfm-comment';
}
<?php

namespace common\helpers\Dsn;

use common\helpers\Dsn;

/**
 * PgsqlDsn
 *
 */
class PgsqlDsn extends Dsn
{

    protected $defaultPort = '5432';

}
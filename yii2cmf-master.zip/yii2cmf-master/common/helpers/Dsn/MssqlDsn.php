<?php

namespace common\helpers\Dsn;

use common\helpers\Dsn;

/**
 * MssqlDsn
 *
 */
class MssqlDsn extends Dsn
{

}
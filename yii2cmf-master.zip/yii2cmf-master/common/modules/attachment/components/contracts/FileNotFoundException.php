<?php

namespace common\modules\attachment\components\contracts;

use Exception;

class FileNotFoundException extends Exception
{
    //
}

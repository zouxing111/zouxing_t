<?php
/**
 * Created by PhpStorm.
 * User: yidashi
 * Date: 2016/11/7
 * Time: 下午7:35
 */

namespace common\modules\area;


class Module extends \common\modules\Module
{

}